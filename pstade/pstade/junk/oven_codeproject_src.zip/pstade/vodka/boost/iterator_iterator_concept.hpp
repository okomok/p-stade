

#if defined(_MSC_VER)
    #pragma warning(push)
    #pragma warning(disable: 4100) // unreferenced formal parameter
    #include <boost/iterator/iterator_concepts.hpp>
    #pragma warning(pop)
#endif
