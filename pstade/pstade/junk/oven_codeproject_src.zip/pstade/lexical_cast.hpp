#ifndef PSTADE_LEXICAL_CAST_HPP
#define PSTADE_LEXICAL_CAST_HPP


// PStade.Wine
//
// Copyright Shunsuke Sogame 2005-2006.
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)


#include <string>
#include <boost/lexical_cast.hpp>
#include <boost/utility/result_of.hpp>
#include <pstade/automatic.hpp>
#include <pstade/auxiliary.hpp>
#include <pstade/deduced_const.hpp>


namespace pstade {


    template<class To>
    struct op_lexical_cast
    {
        typedef To result_type;

        template<class From>
        To operator()(From const& from) const
        {
            return boost::lexical_cast<To>(from);
        }
    };


    template<class To, class From> inline
    typename boost::result_of<op_lexical_cast<To>(PSTADE_DEDUCED_CONST(From)&)>::type
    lexical_cast(From const& from)
    {
        return op_lexical_cast<To>()(from);
    }


    PSTADE_AUXILIARY0(lexicalized, (automatic< op_lexical_cast<boost::mpl::_> >))


    PSTADE_AUXILIARY0(to_string, (op_lexical_cast<std::string>))
    PSTADE_AUXILIARY0(to_wstring, (op_lexical_cast<std::wstring>))


} // namespace pstade


#endif
