#ifndef PSTADE_GRAVY_SDK_WINDOWS_HPP
#define PSTADE_GRAVY_SDK_WINDOWS_HPP


// PStade.Gravy
//
// Copyright Shunsuke Sogame 2007.
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)


#if !defined(PSTADE_GRAVY_NEVER_INCLUDE_SDK_WINDOWS_H) // for MFC
    #include <windows.h>
#endif


#endif
