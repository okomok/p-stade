

#if defined(_MSC_VER)
    #pragma warning(push)
    #pragma warning(disable: 4244) // possible loss of data
    #pragma warning(disable: 4267) // possible loss of data
    #include <boost/numeric/conversion/cast.hpp>
    #pragma warning(pop)
#endif
