

#if defined(_MSC_VER)
    #pragma warning(push)
    #pragma warning(disable: 4100) // unreferenced formal parameter
    #include <boost/assign/ptr_list_of.hpp>
    #pragma warning(pop)
#endif
