

#if defined(_MSC_VER)
    #pragma warning(push)
    #pragma warning(disable: 4244) // conversion from '__int64' to 'int', possible loss of data
    #include <boost/iterator/iterator_adaptor.hpp>
    #pragma warning(pop)
#endif
