

#if defined(_MSC_VER)
    #pragma warning(push)
    #pragma warning(disable: 4127) // conditional expression is constant
    #include <boost/ptr_container/ptr_vector.hpp>
    #pragma warning(pop)
#endif
