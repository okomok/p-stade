

#if defined(_MSC_VER)
    #pragma warning(push)
    #pragma warning(disable: 4913) // user defined binary operator ',' exists but no overload could convert all operands, default built-in binary operator ',' used
    #include <boost/detail/is_incrementable.hpp>
    #pragma warning(pop)
#endif
