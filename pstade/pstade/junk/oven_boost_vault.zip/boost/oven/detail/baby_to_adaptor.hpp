#ifndef PSTADE_OVEN_DETAIL_BABY_TO_ADAPTOR_HPP
#define PSTADE_OVEN_DETAIL_BABY_TO_ADAPTOR_HPP
#include "./prefix.hpp"


// PStade.Oven
//
// Copyright Shunsuke Sogame 2005-2007.
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)


#include <boost/preprocessor/facilities/identity.hpp>
#include <boost/preprocessor/cat.hpp>
#include <boost/oven/pstade/egg/function.hpp>
#include <boost/oven/pstade/egg/pipable.hpp>
#include <boost/oven/pstade/pod_constant.hpp>
#include <boost/oven/pstade/unparenthesize.hpp>


#define PSTADE_OVEN_BABY_TO_ADAPTOR(O, F) \
    typedef pstade::egg::function<PSTADE_UNPARENTHESIZE(F)> BOOST_PP_CAT(op_make_, O); \
    PSTADE_POD_CONSTANT((BOOST_PP_CAT(op_make_, O)), BOOST_PP_CAT(make_, O)) = {{}}; \
    PSTADE_POD_CONSTANT((pstade::egg::result_of_pipable<BOOST_PP_CAT(op_make_, O)>::type), O) = PSTADE_EGG_PIPABLE_RESULT_INITIALIZER(BOOST_PP_IDENTITY({{}})); \
/**/


#endif
